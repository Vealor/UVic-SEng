/* Jakob Roberts
 * CSC360
 * Assignment 1
 * 
 * Tasks:
 * 	1: Run Linux External Commands
 * 	2: Implement:
 *		CD & update prompt
 * 	3: maintain DS and implement:
 *		bg with &
 *		bglist
 * 		
 * 	Bonus: fg, bgkill, bgstop, bgstart
 */
/*===============================================*/
#include "RSI.h"
/*===============================================*/
/*===============================================*/
typedef struct process_structure{
	char* pexec;
	char* status;
	pid_t PID;
	struct process_structure* Next;
}Process;

Process* headproc = NULL;

/*===============================================*/
char* doMalloc(int size){
	char* attempt = malloc(size);
	if(attempt == NULL){
		printf("<<ERROR>>: Not enough memory. Quitting.\n");
		exit(EXIT_FAILURE);
	}
	return attempt;
}
/*===============================================*/
char* printPrompt(){
	char* p1 = "RSI: ";
	char* p2 = doMalloc(PATH_MAX);
	char* p3 = " > ";
	/* try and get CWD, check size of prompt! */
	while(!getcwd(p2,PATH_MAX)){
		if(errno==ERANGE){
			if((p2 = realloc(p2, 2*PATH_MAX))==NULL){
				printf("<<ERROR>>: Not enough memory. Quitting.\n");
				exit(EXIT_FAILURE);
			}
		}else{
			perror("prompt print");
			exit(EXIT_FAILURE);
		}
	}
	char* theprompt = doMalloc(strlen(p1)+strlen(p2)+strlen(p3)+1);
	strcpy(theprompt, p1);
	strcat(theprompt, p2);
	strcat(theprompt, p3);
	free(p2);
	return(theprompt);
}
/*===============================================*/
int parser(char* input, char** tokline, int insize){
	int increment = 0; /* token increment */
	char* tokdelims = " \t\n";
	tokline[increment] = strtok(input,tokdelims);
	while(tokline[increment]){
		if(increment == (insize-1)){
			insize*=2;
			if((tokline = realloc(tokline, insize*sizeof(char*)))==NULL){
				printf("<<ERROR>>: Not enough memory. Quitting.\n");
				exit(EXIT_FAILURE);
			}
		}
		tokline[++increment] = strtok(NULL,tokdelims);
	}
	return increment;	
}
/*===============================================*/
void execute(char** linetok, int linelen){
	/* need to implement struct for a process to LL them */
	/*Process child;
	child.PID = fork();*/
	pid_t child = fork();
	int bgflag = 0;
	int status;
	if(child >= 0){
		if(child==0){ /*child in fg*/
			if(!strcmp(linetok[linelen-1],"&")){
				linetok[linelen-1] = NULL;
				bgflag = 1;
			}
			/* attempt to switch to new process */
			if(execvp(linetok[0],linetok)){
				perror("execvp FAILED!");
			}
			exit(EXIT_FAILURE);
		}else if(child >0){ /*child in bg*/
			if(!strcmp(linetok[linelen-1],"&")){
				printf("Child born=>  PID:%d\tProcess:%s\n",child,linetok[0]);
			}else{
				if(waitpid(child,&status,WNOHANG) == -1){
					perror("waitpid problem 1");
				}
				while(!WIFEXITED(status) && !WIFSIGNALED(status)){
					if(waitpid(child,&status,WNOHANG)==-1){
						perror("waitpid problem 2");
					}
				}
			}
		}
	}else{
		perror("fork() problem");
	}
	if(!bgflag){
		wait(&status);
	}
}
/*===============================================*/
void chgDir(char** line, int items){
	if(items > 2){
		printf("usage:  cd [dir]\n");
	}else{
		if(items==1 || !strcmp(line[1],"~")){
			char* theHome = getenv("HOME");
			if(theHome==NULL){
				printf("<<ERROR>>: Can't get home directory.\n");
			}else{
				if(chdir(theHome)==-1){
					perror("chdir error");
				}
			}
		}else{
			if(chdir(line[1])==-1){
				perror("chdir error");
			}
		}
	}
}
/*===============================================*/
int main(){
	system("clear");
	
	char* prompt = printPrompt();
	int quitcode = 0;
	while(!quitcode){
		char* input = readline(prompt);
		if(!strcmp(input, "quit")){
			quitcode = 1;
		}else{
			int linelen = ARG_MAX;
			char** linetok = (char**)doMalloc(linelen*sizeof(char*));
			linelen = parser(input,linetok,linelen);
			if(linelen > 0){
				if(!strcmp(linetok[0],"cd")){
					/* do CD */
					chgDir(linetok,linelen);
					free(prompt);
					prompt = printPrompt();
				}else if(!strcmp(linetok[0],"bglist")){
					/* do bglist */
					//not implemented
					printf("not implemented!!!!\n");
				}else{
					execute(linetok,linelen);
				}
			}
			free(linetok[0]);
			free(linetok);
		}
		setbuf(stdin,NULL);
	}
	printf("----- EXITING NORMALLY -----\n");
	free(prompt);
	return(0);	
}
/*===============================================*/
/*===============================================*/
/*===============================================*/




