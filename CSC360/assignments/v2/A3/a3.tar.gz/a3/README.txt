/************************************************
 * Jakob Roberts  -  v00484900
 * CSC360
 * Simple File System
 * README.txt
 ************************************************/

#################################################
#  Functionality of "parts.c" explained:   
#################################################

----- ./diskinfo -----
Lists the information of the image provided.



----- ./disklist -----
Lists the files in the image provided and
classifies them as either files or directories.

Can't search within a subdirectory unfortunately.


----- ./diskget -----
Pulls a file of a certain filename from the disk.

Error if the file doesn't exist.

No support for subdirectories unfortunately. :(


----- ./diskput -----
Puts a file onto the disk.

Currently has trouble putting data into the root
directory listing. It can however find and create
the correct FAT entries!

Error if the filename already exists.
Error if not enough free space on image.
Error if root directory allocation full.

No support for subdirectories unfortunately. :(