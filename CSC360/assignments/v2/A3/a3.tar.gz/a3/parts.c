/******************************************
 * Jakob Roberts  -  v00484900
 * CSC360
 * Simple File System
 * parts.c
 ******************************************/
#include "parts.h"

//## PART 1 #####################################
void print_info(superblock_t info){
	printf("Super block information:\n");
	printf("Block size: %d\n", info.block_size);
	printf("Block count: %d\n", info.block_count);
	printf("FAT starts: %d\n", info.fat_start);
	printf("FAT blocks: %d\n", info.fat_blocks);
	printf("Root directory start: %d\n", info.root_start);
	printf("Root directory blocks: %d\n\n", info.root_blocks);
	printf("Fat information:\n");
	printf("Free Blocks: %d\n", info.free_blocks);
	printf("Reserved blocks: %d\n", info.reserved_blocks);
	printf("Allocated blocks: %d\n", info.allocated_blocks);
}
//----------------------------------------------------
int getnum(unsigned char * mmap, int offset, int length){
  int i = 0 , retVal = 0;
  char *tmp = (char *)malloc(sizeof(char) * length);
  memcpy(tmp, mmap+offset, length);
  for(i=0; i < length; i++){
    retVal += ((int)(tmp[i]&0xFF)<<(8*(length - i - 1)));
  }
  free(tmp);
  return retVal;
};
//----------------------------------------------------
void countFAT(unsigned char * mmap, superblock_t *info){
	uint32_t i = 0, tmp, step = 4, start, end;
	start  = info->fat_start * info->block_size;
	end    = (info->fat_start+info->fat_blocks) * info->block_size;
	for(i=start;i<end;i+=step){
		tmp=getnum(mmap,i,step);
		if(tmp==0){
			info->free_blocks++;
		}else if(tmp==1){
			info->reserved_blocks++;
		}else{
			info->allocated_blocks++;
		}
	}
}
//----------------------------------------------------
void getdiskinfo(unsigned char *data, superblock_t *info){
	info->block_size       = getnum(data,8,2);
	info->block_count      = getnum(data,10,4);
	info->fat_start        = getnum(data,14,4);
	info->fat_blocks       = getnum(data,18,4);
	info->root_start       = getnum(data,22,4);
	info->root_blocks      = getnum(data,26,4);
	info->free_blocks      = 0;
	info->reserved_blocks  = 0;
	info->allocated_blocks = 0;
	countFAT(data,info);
}

//## PART 2 #####################################
tm getDate(unsigned char * mmap, int offset){
	tm retVal;
  retVal.tm_year = getnum(mmap, offset    , 2);
  retVal.tm_mon  = getnum(mmap, offset + 2, 1);
  retVal.tm_mday = getnum(mmap, offset + 3, 1);
  retVal.tm_hour = getnum(mmap, offset + 4, 1);
  retVal.tm_min  = getnum(mmap, offset + 5, 1);
  retVal.tm_sec  = getnum(mmap, offset + 6, 1);
  return retVal;
}
//----------------------------------------------------
void  getStr(char **filename,unsigned char *mapping, uint32_t offset, uint32_t length){
  char *str = (char*)malloc(sizeof(char)*length);
  memcpy(str, mapping + offset, length);
  strcat(str, "\0");
  strcpy(*filename, str);
  free(str);
}
//----------------------------------------------------
void print_diskfile(file_t *file){
	if(file->status==3){
		printf("F ");
	}else if(file->status==5){
		printf("D ");
	}else{
		fprintf(stderr,"Error: wrong file status found!");
		exit(EXIT_FAILURE);
	}
	printf("%10d ", file->size);
	printf("%30s ", file->filename);
	printf("%04d/", file->modify_time.tm_year);
	printf("%02d/", file->modify_time.tm_mon);
	printf("%02d ", file->modify_time.tm_mday);
	printf("%02d:", file->modify_time.tm_hour);
	printf("%02d:", file->modify_time.tm_min);
	printf("%02d\n",file->modify_time.tm_sec);
}
//----------------------------------------------------
void getdisklist(unsigned char *data, superblock_t *info){
	file_t file;

	int currentblock = info->root_start;
	int numblocks    = info->root_blocks;
	int FATstart     = info->fat_start * info->block_size;
	int nextblock,i;
	do{
		nextblock = getnum(data,FATstart+(currentblock*4),4);
		for(i=0;i<8;i++){
				int filename_length = 31;
				int loc = (currentblock*info->block_size)+(64*i);
				file.status = getnum(data,loc,1);
				if(file.status==3 || file.status==5){
					file.starting_block = getnum(data,loc+1,4);
					file.block_count    = getnum(data,loc+5,4);
					file.size           = getnum(data,loc+9,4);
					file.modify_time    = getDate(data,loc+13 );
					file.create_time    = getDate(data,loc+20 );
					file.filename       = (char*)malloc(sizeof(char)*filename_length);
					getStr(&file.filename,data,loc+27,filename_length);
					print_diskfile(&file);
					free(file.filename);
				}
			}

		currentblock = nextblock;
		numblocks--;
	}while(numblocks>0);
}

//## PART 3 #####################################
void copyFile(unsigned char *data, superblock_t *info, char* name, file_t file){
	int size = file.size;
	uint32_t start;
	start  = info->fat_start * info->block_size;

	FILE *fout = fopen(name, "w");
	// printf("FILE SIZE: %d\n",size);
	int currentblock = file.starting_block;
	int nextblock;
	do{
		// printf("CURRENT BLOCK: %d\n",currentblock);
		nextblock = getnum(data,start+(currentblock*4),4);
		if((size-(info->block_size))<0){
			// printf("one %d\n",size);
			fwrite(data+(currentblock*info->block_size),size,1,fout);
			size = 0;
		}else{
			// printf("two %d\n",size);
			size-=info->block_size;	
			fwrite(data+(currentblock*info->block_size),(info->block_size),1,fout);
		}
		currentblock = nextblock;
	}while(size>0);
}
//----------------------------------------------------
void dodiskget(unsigned char *data, superblock_t *info, char* path,char* name){
	file_t file;

	int currentblock = info->root_start;
	int numblocks    = info->root_blocks;
	int FATstart     = info->fat_start * info->block_size;
	int nextblock,i;
	do{
		nextblock = getnum(data,FATstart+(currentblock*4),4);
		for(i=0;i<8;i++){
				int filename_length = 31;
				int loc = (currentblock*info->block_size)+(64*i);
				file.status = getnum(data,loc,1);
				if(file.status==3 || file.status==5){
					file.filename  = (char*)malloc(sizeof(char)*filename_length);
					getStr(&file.filename,data,loc+27,filename_length);
					if(strcmp(path,file.filename)==0){
						file.starting_block = getnum(data,loc+1,4);
						file.block_count    = getnum(data,loc+5,4);
						file.size           = getnum(data,loc+9,4);
						file.modify_time    = getDate(data,loc+13 );
						file.create_time    = getDate(data,loc+20 );
						copyFile(data,info,name,file);
						return;
					}
				}
			}
		currentblock = nextblock;
		numblocks--;
	}while(numblocks>0);
	fprintf(stderr,"File not found.\n");
}

//## PART 4 #####################################
int checkFileName(unsigned char *data, superblock_t *info, char* name, char* path){
	file_t file;

	int currentblock = info->root_start;
	int numblocks    = info->root_blocks;
	int FATstart     = info->fat_start * info->block_size;
	int nextblock,i;
	do{
		nextblock = getnum(data,FATstart+(currentblock*4),4);
		for(i=0;i<8;i++){
				int filename_length = 31;
				int loc = (currentblock*info->block_size)+(64*i);
				file.status = getnum(data,loc,1);
				if(file.status==3 || file.status==5){
					file.filename  = (char*)malloc(sizeof(char)*filename_length);
					getStr(&file.filename,data,loc+27,filename_length);
					if(strcmp(name,file.filename)==0){
						fprintf(stderr,"Filename already exists!\n");
						return 1;
					}
				}
			}
		currentblock = nextblock;
		numblocks--;
	}while(numblocks>0);
	return 0;
}
//----------------------------------------------------
void write_num(unsigned char *data, int num, size_t offset, size_t size){
  int i;
  unsigned int mask = 0xFF;
  for(i = 0; i < size; i++){
    data[offset+i] = (num & (mask << 8*i)) >> (i*8);
    // printf("data:%d\n",(int)data[offset+i]);
  }
  // int i = 0 , retVal = 0;
  // char *tmp = (char *)malloc(sizeof(char) * length);
  // memcpy(tmp, mmap+offset, length);
  // for(i=0; i < length; i++){
  //   retVal += ((int)(tmp[i]&0xFF)<<(8*(length - i - 1)));
  // }
  // free(tmp);
  // return retVal;

  // char *tmp = (char *)malloc(sizeof(char) * length);
  //do memcopy
  //go in reverse of above to put into while bitshifting!!

}
//----------------------------------------------------
void create_root_entry(unsigned char* data,superblock_t *info,char *filename, int size, int free_entry){
  //find open root dir
  //input values to root dir, referencing fat
  //-------------------------------------
  file_t file;

	int currentblock = info->root_start;
	int numblocks    = info->root_blocks;
	int FATstart     = info->fat_start * info->block_size;
	int nextblock,i;
	do{
		nextblock = getnum(data,FATstart+(currentblock*4),4);
		for(i=0;i<8;i++){
				// int filename_length = 31;
				int loc = (currentblock*info->block_size)+(64*i);
				file.status = getnum(data,loc,1);
				if(file.status==0){ //then make new file!
					write_num(data,3,loc,1);			//status
					// printf("FREE ROOT ENTRY: %d\n",free_entry);
					write_num(data,free_entry,loc+1,4);	//starting block
					int blocks = size/info->block_size;
					if((size%info->block_size)>0){blocks++;}
					write_num(data,blocks,loc+5,4);	//number of blocks
					write_num(data,size,loc+9,4);	//file size
					// getDate(data,loc+13 );		//create time
					// getDate(data,loc+20 );		//modify time
					// write_num(data,loc+);
					return;
				}
			}
		currentblock = nextblock;
		numblocks--;
	}while(numblocks>0);
	fprintf(stderr,"No room in root dir for a new entry.\n");
}
//----------------------------------------------------
//find empty fat entry for beginning of new file
uint32_t freeFATentry(unsigned char * mmap, superblock_t *info, int prev){
	uint32_t i = 0, tmp, step = 4, start, end;
	start  = info->fat_start * info->block_size;
	end    = (info->fat_start+info->fat_blocks) * info->block_size;
	for(i=start;i<end;i+=step){
		tmp=getnum(mmap,i,step);
		if(tmp==0&&(start+i!=prev)){
			return (start+i);
		}
	}
	return 0;
}
//----------------------------------------------------
void dodiskput(unsigned char *data, superblock_t *info, char* filename, char* path){
	int fin, remain, next, towrite, last;
	int i, tmp, free_entry;
	struct stat sf;
	unsigned char* input;

	if(checkFileName(data,info,filename,path)){
		return; //filename already exists
	}else if((fin = open(filename, O_RDONLY))){
		stat(filename, &sf);
		input = mmap(NULL,sf.st_size, PROT_READ, MAP_SHARED, fin, 0);
		if(info->free_blocks*info->block_size < sf.st_size){
			fprintf(stderr,"Not enough free space on disk image!\n");
		}else{
			free_entry = freeFATentry(data,info,0);//fcluster
			create_root_entry(data, info, filename, (int)sf.st_size, free_entry);
			remain = (int)sf.st_size;
			for(next = free_entry,i=0;remain>0;remain-=info->block_size,i++){
				// pentry = physical_entry(next);
				last = remain > 512 ? 0 : 1;
        towrite = last ? 512 : remain;
        memcpy(data+next*info->block_size, input+(i*info->block_size), towrite);
        if(last){
        	write_num(data,0xFFF,info->fat_start+(next*4),4);
        }else{
          tmp = next;
          next = freeFATentry(data,info,tmp);
          write_num(data,next,info->fat_start+(tmp*4),4);
        }
			}
		}
	}
}

//###############################################
int main(int argc, char** argv){
	int fd;
	unsigned char *data;
	struct stat sf;
	superblock_t info;

	if(argc<2){
		fprintf(stderr,"Error: Please specify disk image.");
		exit(EXIT_FAILURE);
	}
	fd = open(argv[1], O_RDONLY);
	if(fd==-1){
		fprintf(stderr,"Failed to open file '%s'\n", argv[1]); 
    exit(EXIT_FAILURE); 
	}
	fstat(fd, &sf);
	data = mmap(NULL,sf.st_size, PROT_READ, MAP_SHARED, fd, 0);
	getdiskinfo(data, &info);

	//## PART 1 ###################
	#if defined(PART1)
	// printf ("Part 1: diskinfo\n");
	fd = open(argv[1], O_RDONLY);
	if(fd==-1){
		fprintf(stderr,"Failed to open file '%s'\n", argv[1]); 
    exit(EXIT_FAILURE); 
	}
	fstat(fd, &sf);
	data = mmap(NULL,sf.st_size, PROT_READ, MAP_SHARED, fd, 0);
	getdiskinfo(data, &info);
	if (argc != 2){
    fprintf(stderr,"Error: Usage: %s <path-to-disk-images>\n",argv[0]);
    exit(EXIT_FAILURE);
  }else{
  	print_info(info);
  }
  return 0;

	//## PART 2 ###################
	#elif defined(PART2)
	// printf ("Part 2: disklist\n");
	fd = open(argv[1], O_RDONLY);
	if(fd==-1){
		fprintf(stderr,"Failed to open file '%s'\n", argv[1]); 
    exit(EXIT_FAILURE); 
	}
	fstat(fd, &sf);
	data = mmap(NULL,sf.st_size, PROT_READ, MAP_SHARED, fd, 0);
	getdiskinfo(data, &info);
	if (argc<2||argc>3){
    printf("Error: Usage: %s <path-to-disk-images> <directory>\n",argv[0]);
    exit(EXIT_FAILURE);
  }else{
		getdisklist(data,&info);
  }

	//## PART 3 ###################
	#elif defined(PART3)
	// printf ("Part 3: diskget\n");
	fd = open(argv[1], O_RDONLY);
	if(fd==-1){
		fprintf(stderr,"Failed to open file '%s'\n", argv[1]); 
    exit(EXIT_FAILURE); 
	}
	fstat(fd, &sf);
	data = mmap(NULL,sf.st_size, PROT_READ, MAP_SHARED, fd, 0);
	getdiskinfo(data, &info);
	if (argc != 4){
    printf("Error: Usage: %s <disk-image-path> <file-to-get> <new-filename>\n",argv[0]);
    exit(EXIT_FAILURE);
  }else{
  	if(argv[2][0]=='/'){
  		argv[2]++;
  	}
  	dodiskget(data, &info, argv[2], argv[3]);
  }


	//## PART 4 ###################
	#elif defined(PART4)
	// printf ("Part 4: diskput\n");
	fd = open(argv[1], O_RDWR);
	if(fd==-1){
		fprintf(stderr,"Failed to open file '%s'\n", argv[1]); 
    exit(EXIT_FAILURE); 
	}
	fstat(fd, &sf);
	data = mmap(NULL,sf.st_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
	getdiskinfo(data, &info);
	if (argc>4||argc<2){
    printf("Error: Usage: %s <path-to-disk-image> <local-file> <location-in-image>\n",argv[0]);
    exit(EXIT_FAILURE);
  }else if(argc==4){
  	dodiskput(data, &info, argv[2], argv[3]);
  }else{
  	// dodiskput(data, &info, argv[2], NULL);
  }

//###################################
	//## PART ERROR ###################
	#else
	#error "PART[1234] must be defined"
	#endif
	return 0;
}
