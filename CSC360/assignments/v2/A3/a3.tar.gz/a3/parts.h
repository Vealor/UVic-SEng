/******************************************
 * Jakob Roberts  -  v00484900
 * CSC360
 * Simple File System
 * header file for parts.c
 ******************************************/

#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>

#define MAXPATH_LEN 31

typedef struct tm tm;

// Super block
typedef struct superblock_t {
	//uint8_t fs_id [8];
	uint16_t block_size;
	uint32_t block_count;
	uint32_t fat_start;
	uint32_t fat_blocks;
	uint32_t root_start;
	uint32_t root_blocks;
	int free_blocks;
	int reserved_blocks;
	int allocated_blocks;
} superblock_t;

// Directory entry
typedef struct file_t {
	uint8_t status;
	uint32_t starting_block;
	uint32_t block_count;
	uint32_t size;
	tm modify_time;
	tm create_time;
	char* filename;
	// uint8_t unused[6];
} file_t;

//---tm struct---
//struct tm {
//   int tm_sec;         /* seconds,  range 0 to 59          */
//   int tm_min;         /* minutes, range 0 to 59           */
//   int tm_hour;        /* hours, range 0 to 23             */
//   int tm_mday;        /* day of the month, range 1 to 31  */
//   int tm_mon;         /* month, range 0 to 11             */
//   int tm_year;        /* The number of years since 1900   */
//   int tm_wday;        /* day of the week, range 0 to 6    */
//   int tm_yday;        /* day in the year, range 0 to 365  */
//   int tm_isdst;       /* daylight saving time             */	
//};