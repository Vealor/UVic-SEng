########################################################
README file for a5python.py
########################################################

USE:

python a5python.py <input>

where <input> is a director ID from the imdb database:
	ie 'Nolan, Christopher (I)'

output is HTML format so recomment piping to file:
	python a5python.py <input> > <filename>.html

========================================================
For further questions contact jakob.m.roberts@gmail.com
