//## INCLUDES ##
#include <pcap.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <netinet/if_ether.h>
#include <netinet/ip_icmp.h>
#include <net/if.h>
#include <arpa/inet.h>
#include <inttypes.h>
#include <time.h>

//## PREDEFINITIONS ##
#define MAX_NUM_CONNECTION 1000
#define MAX_STR_LEN 1000
#define MAX_RESPONSES 80
#define NUM_PROTOCOLS 256

struct packet{
	char dst[INET_ADDRSTRLEN];
	char src[INET_ADDRSTRLEN];
	int ttl;
	int protocol;
	int flags;
	u_short offset;
	u_short id;
	int fragments;
	float time;

	int port_src;
	int port_dest;

	//for ICMP
	uint16_t sequence;

	//for UDP
	uint16_t source;
	uint16_t dest;
};

struct connection{
	struct packet init; //initial request
	int confirmret;			//confirm return query
	struct packet end;  //last request

	int num_responses;
	struct packet responses[MAX_RESPONSES];
	int fragments;
	int lastoffset;
	int offset;
	int sdev;
};

void printconnection(struct connection c){
	int i,pcols[NUM_PROTOCOLS];
	if(c.num_responses == 0){return;}
	for(i=0;i<NUM_PROTOCOLS;i++) pcols[i]=0;
	pcols[c.init.protocol]++;
	printf("The IP address of the source node: %s\n", 							c.init.src);
	printf("The IP address of the ultimate destination node: %s\n", c.init.dst);
	printf("The IP addresses of the intermediary destination nodes:\n");
	for(i = 0; i < c.num_responses; i++){
		pcols[c.responses[i].protocol] = 1;
		printf("     router %d: %s\n", i+1, c.responses[i].src);
	}
	printf("The values in the protocol field of the IP headers:\n");
	for(i = 0; i < NUM_PROTOCOLS; i++){
		if(pcols[i] > 0){
			if      (i == 1){
				printf("     %d: ICMP",i);
			}else if(i == 17){
				printf("     %d: UDP",i);
			}
			printf("\n");
		}
	}
	printf("\n\nThe number of fragments created from the original datagram is: %d\n", c.fragments);
	printf("The offset of the last fragment is: %d\n\n", 													c.lastoffset);
	printf("==========\n");
}




// struct myrequest{
// 	struct myIP request;
// 	struct myIP last;
// 	int r;
// 	struct myIP responses[RESPONSES];
// 	int fragments;
// 	int lastoffset;
// 	int offset;
// 	int sd;
// };





// struct packet_two{
// 	int size;
// 	double ts;
// 	int length;
// 	int ID;
// 	int TTL;
// 	int protocol;

// 	char ip_src[MAX_STR_LEN];
// 	char ip_dest[MAX_STR_LEN];
// 	int port_src;
// 	int port_dest;

// 	uint8_t tcp_flags;


// 	struct packet* nextpacket;
// };




// struct IPHDR{
// 	uint8_t 	tos;
// 	uint16_t 	tot_len;
// 	uint16_t 	id;
// 	uint16_t 	frag_off;
// 	uint8_t 	ttl;
// 	uint8_t 	protocol;
// 	uint16_t 	check;
// 	uint32_t 	saddr;
// 	uint32_t 	daddr;
// };



//===============================
// struct TCP_hdr{
// 	uint16_t 	src_port;
// 	uint16_t 	dst_port;
// 	uint32_t 	sent_seq;
// 	uint32_t 	recv_ack;
// 	uint8_t 	data_off;
// 	uint8_t 	tcp_flags;
// 	uint16_t 	rx_win;
// 	uint16_t 	cksum;
// 	uint16_t 	tcp_urp;
// };

// PACKET FOR CONNECTION STRUCT


// CONNECTION STRUCT / PACKET LIST HEAD
// struct connection{
// 	struct packet* nextpacket;
//   char ip_src[MAX_STR_LEN]; /*source ip*/
//   char ip_dest[MAX_STR_LEN]; /*destination ip*/
//   int port_src; /*source port number*/
//   int port_dest; /*destination port number*/

//   int syn_count; /*flag count*/
//   int fin_count;
//   int rst_count;
//   struct timeval starting_time;
//   struct timeval ending_time;
//   double duration;

//   int num_packet_src; /*number of packets sent out by source*/
//   int num_packet_dst; /*number of packets sent out by destination*/
//   int num_total_packets;

//   int cur_data_len_src; /*num data bytes*/
//   int cur_data_len_dst; /*num data bytes*/
//   int cur_total_data_len;

//   uint16_t max_win_size; /*max window size*/
//   uint16_t min_win_size; /*min window size*/
//   double sum_win_size;

//   // struct round_trip rtt_ary_src[MAX_NUM_CONNECTION/4]; /*assume 1000*/
//   int rtt_ary_src_len; /*the size of the rtt_ary_src array*/
//   // struct round_trip rtt_ary_dst[MAX_NUM_CONNECTION/4]; /*assume 1000*/
//   int rtt_ary_dst_len; /*the size of the rtt_ary_dst array*/
//   int is_set;
// };
