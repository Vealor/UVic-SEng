/* Assignment 3
 * Jakob Roberts
 * CSC 361
 */
//===================================================================
#include "p3.h"
//===================================================================
//===================================================================
//===================================================================

// Process a received packet and enter into a packet struct
void process_packet(struct packet *p,u_char *pack,struct timeval t_init, struct timeval t_pack,u_int caplen){

	// struct iphdr* iphead;
	struct ip* iphead;
	unsigned short iphdr_length;

	// Bypass Ethernet Header - return if not a full header
	if (caplen < sizeof(struct ether_header)){
		return;
	}else{
		pack += sizeof(struct ether_header);
		caplen -= sizeof(struct ether_header);
	}

	// Gather IP Header info - return if not a full header
	if (caplen < sizeof(struct ip)){
		return;
	}else{
		// Get IP header information
		iphdr_length = iphead->ip_hl*4;
		iphead = (struct ip*) pack;
		inet_ntop( AF_INET, &iphead->ip_dst, p->dst, INET_ADDRSTRLEN );
		inet_ntop( AF_INET, &iphead->ip_src, p->src, INET_ADDRSTRLEN );
		p->ttl 			= (int)iphead->ip_ttl;
		p->protocol = (int)iphead->ip_p;
		p->offset 	= ntohs(iphead->ip_off);
		if(p->offset & 0x2000){
			// printf("flag1 ");
			p->flags+=1;
			p->offset = p->offset ^ 0x2000;
		}
		if(p->offset & 0x4000){
			// printf("flag2 ");
			p->flags+=2;
			p->offset = p->offset ^ 0x4000;
		}
		if(p->offset & 0x8000){
			// printf("flag3 ");
			p->flags+=4;
			p->offset = p->offset ^ 0x8000;
		}
		p->offset *=8;

		p->id = ntohs(iphead->ip_id);
		p->fragments = 0;
		char ti[256]; sprintf(ti,"%d.%06d",(int)t_pack.tv_sec,(int)t_pack.tv_usec);
		char t0[256]; sprintf(t0,"%d.%06d",(int)t_init.tv_sec,(int)t_init.tv_usec);
		p->time = strtod(ti,NULL) - strtod(t0, NULL);

		if(p->protocol == 1){ //if ICMP
			pack += iphdr_length; //make shift for next header type
			struct icmphdr* icmphead = (struct icmphdr*)pack; // pull ICMP info from packet
			p->sequence = (int16_t)ntohs(icmphead->un.echo.sequence);
		}else if(p->protocol == 17){ //if UDP
			pack += iphdr_length; //make shift for next header type
			struct udphdr* udphead = (struct udphdr*)(pack);
			p->source = (int16_t)ntohs(udphead->source);
			p->dest   = (int16_t)ntohs(udphead->dest);
			// printf("source: %d\n",p->source);
			// printf("dest:   %d\n",p->dest);
		}
	}
}

//===================================================================
// <><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
int main(int argc,char **argv){
	int i,j,k; 													// for looping
	int numpak = 0;									//number of packets
	int numcon = 0;									//number of connections/requests
	pcap_t *capfile;								//init capfile
	char errbuf[PCAP_ERRBUF_SIZE]; 	//ERR buffer for [2]
	u_char *pack;										//pointer to packet
	// const unsigned char *pack;
	struct pcap_pkthdr header;			//packet header

	// struct TCP_hdr tcp;

	//[1] Check arg input
	if (argc < 2) {
    fprintf(stderr, "Usage: %s <pcap>\n", argv[0]);
    exit(1);
  }

  //[2] Open PCAP File && check
	capfile = pcap_open_offline(argv[1], errbuf);
	if (capfile == NULL) {
		fprintf(stderr,"Couldn't open pcap file %s: %s\n", argv[1], errbuf);
		return(2);
	}

	//[3] Get QTY packets && re-init capfile
	while(pack = pcap_next(capfile, &header)){numpak++;}
	pcap_close(capfile);
	capfile = pcap_open_offline(argv[1], errbuf);

	//[4] Init packets array
	struct packet PA[numpak];
	for(i = 0; i < numpak; i++){
		strcpy(PA[i].dst, " ");
		strcpy(PA[i].src, " ");
				   PA[i].ttl = -1;
				   PA[i].protocol = 0;
				   PA[i].time = 0.0;
				   PA[i].flags = 0;
				   PA[i].offset = 0;
				   PA[i].fragments = -1;
				   PA[i].id = 0;
				   PA[i].sequence = -1;
				   PA[i].source = 0;
				   PA[i].dest = 0;
	}

	//[5] Extract packet information
	int paknum = 1;
	struct timeval timeinit;
	fflush(stdout);
	while (pack = pcap_next(capfile,&header)){
		// printf("%d >> ",paknum);
		if(paknum==1){
			timeinit = header.ts;
		}
		// struct packet* data;
		if(pack != NULL){
			process_packet(&PA[paknum-1],pack,timeinit,header.ts,header.caplen);
		}
		paknum++;
	}

	//[6] Get number of possible connections / requests
	// HAS:
	//	- ICMP
	//	- TTY = 1
	//	- offset = 0
	for(i = 0; i < numpak; i++){
		if((PA[i].protocol == 1 || PA[i].protocol == 17) && (PA[i].ttl == 1) &&
			(PA[i].sequence != 0 || (PA[i].source !=0 && PA[i].dest != 0)) &&
			(PA[i].flags == 0) ){
			numcon++;
		}
	}

	//[7] Init connections/requests
	struct connection reqs[numcon];
	for(i = 0; i < numcon; i++){
		reqs[i].confirmret = 0;
		reqs[i].num_responses=0;
		reqs[i].fragments=0;
		reqs[i].lastoffset=0;
		reqs[i].offset = 0;
		reqs[i].sdev = 0;
	}

	//[8] Set the first requests (repeat [6] but add to created array)
	j = 0; //init for each request that matches
	// HAS:
	//	- ICMP
	//	- TTY = 1
	//	- offset = 0
	for(i=0;i<numpak;i++){
		if((PA[i].protocol == 1 || PA[i].protocol == 17) && (PA[i].ttl == 1) &&
			(PA[i].sequence != 0 || (PA[i].source !=0 && PA[i].dest != 0)) &&
			(PA[i].flags == 0) ){
			reqs[j].init = PA[i];
			j++;
		}
	}

	//[9] Finds fragments for each connection / request set
	for(i = 0; i < numpak; i++){
		for(j = 0; j < numcon; j++){
			if((PA[i].id == reqs[j].init.id) && (PA[i].offset > 0)){
				//increment the fragment count for the packet
				reqs[j].fragments++;
				if(PA[i].offset > reqs[j].lastoffset){
					//if the fragment offset increased, change to new offset
					reqs[j].lastoffset = PA[i].offset;
				}
			}
		}
	}




	//[10] Adds packets to request arrays
	// Decided to go for array method instead of linked list structure, assuming that no more
	// than 80 responses per request are to be made! (not best idea, but eh... hah)
	for(i = 0; i < numpak; i++){
		for(j = 0; j < numcon; j++){
		// 	if(PA[i].protocol == 1 && PA[i].sequence >0){ //do ICMP
				if((reqs[j].init.protocol == 1) &&
					 (PA[i].time > reqs[j].init.time) && //if greater than current initialization time
					 // (PA[i].time < reqs[j+1].init.time) && //if less than next connection's initialization time
					 (strcmp(PA[i].dst, reqs[j].init.src)== 0) ){ //if the packet's destination ip matches the request source ip (return traffic)

					if(j == numcon-1 || PA[i].time < reqs[j+1].init.time){
						if(PA[i].sequence == reqs[j].init.sequence){
							reqs[j].confirmret = 1;
						}
						// printf("%s %s",reqs[j].init.dst,PA[i].src);
						if(strcmp(reqs[j].init.dst, PA[i].src)==0){// if the request destination matches packet source, is last packet!
							reqs[j].end = PA[i];
						}else{ //add packet to response list for the given request
							reqs[j].responses[reqs[j].num_responses] = PA[i];
							reqs[j].num_responses++;
						}
					}
				}

			// }else if(PA[i].sequence == 0){ //do UDP
			// 	if(reqs[j].init.protocol == 17){
			// 		int next = (j+1)%numcon;
			// 		if(strcmp(PA[i].src,reqs[j].init.src) ==0 && strcmp(PA[i].dst,reqs[j].init.dst)==0 ){
			// 			reqs[j].confirmret = 1;
			// 		}

			// 		if(reqs[j].num_responses == reqs[next].num_responses || j == numcon-1){

			// 			if(strcmp(reqs[j].init.dst, PA[i].src)==0){// if the request destination matches packet source, is last packet!
			// 				reqs[j].end = PA[i];
			// 				break;
			// 			}else{ //add packet to response list for the given request
			// 				reqs[j].responses[reqs[j].num_responses] = PA[i];
			// 				reqs[j].num_responses++;
			// 				break;
			// 			}
			// 		}


			// 	}
		// 	}
		}
	}

	//[11] Prints all the request information from the pcap file
	for(i = 0; i < numcon; i++){
		printconnection(reqs[i]);
	}

	//[12] Calculates RTT
	char  used[16*numpak];
	float rtt=0.0;
	float sdev=0;
	float times[numpak];
	int   count=0;
	int   m =0;
	//i j k m
	//n k j i
	for(i = 0; i < numcon; i++){
		for(j=0; j<reqs[i].num_responses;j++){
			if(strstr(used, ("%s to %s",reqs[i].init.src, reqs[i].responses[i].src))==NULL){
				times[count] = reqs[i].responses[j].time - reqs[i].init.time;
				count++;

				for(k = i; k < numcon; k++){
					for(m=0; m < reqs[k].num_responses; m++){
						if((strcmp(reqs[i].init.src,reqs[k].init.src)==0)&&
						(strcmp(reqs[i].responses[j].src,reqs[k].responses[m].src)==0)){
							times[count] = reqs[k].responses[m].time - reqs[k].init.time;
							count++;
						}
					}
				}
				for(k = 0; k<count;k++) rtt+= times[k];
				rtt = rtt/count;
				for(k = 0; k<count;k++){
					times[k] -= rtt;
					times[k] = times[k] * times[k];
					sdev += times[k];
				}
				sdev = sdev/(count-1);
				strcat(used, ("%s to %s||||",reqs[i].init.src, reqs[i].responses[j].src));
				printf("Average RTT for %s to %s is: %fms, the s.d. is: %fms\n", reqs[i].init.src, reqs[i].responses[j].src, rtt*1000, sdev*1000);
				sdev = 0.0;
				rtt = 0.0;
				count=0;
			}
		}
	}

	//[13] Clean up
	pcap_close(capfile);
}


