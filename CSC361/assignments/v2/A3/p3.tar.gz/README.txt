
#################################################
#### Packet Inspection           ################
#################################################
NOTE:
Program considers all connections
in the given pcap file!

######################
~~~~ INSTALLATION ~~~~
run the following in the code folder:

	$ make


########################
~~~~ RUNNING CLIENT ~~~~
Be in the directory where the file was made

	$ ./p3 <PCAP_file>

<PCAP_file> is the file location
of your packet file


########################
########################
########################
