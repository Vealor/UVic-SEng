#include <inttypes.h>
#include <pcap.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
// #include <rte_tcp.h>
// #include <netinet/in.h>
#include <netinet/ip.h>
// #include <net/if.h>
#include <netinet/if_ether.h>
#include <time.h>

#define MAX_NUM_CONNECTION 1000
#define MAX_STR_LEN 1000

// IPHDR INFO
// __u8 	tos
// __u16 	tot_len
// __u16 	id
// __u16 	frag_off
// __u8 	ttl
// __u8 	protocol
// __u16 	check
// __u32 	saddr
// __u32 	daddr

// TCP HEADER STRUCT
struct TCP_hdr{
	uint16_t 	src_port;
	uint16_t 	dst_port;
	uint32_t 	sent_seq;
	uint32_t 	recv_ack;
	uint8_t 	data_off;
	uint8_t 	tcp_flags;
	uint16_t 	rx_win;
	uint16_t 	cksum;
	uint16_t 	tcp_urp;
};

// PACKET FOR CONNECTION STRUCT
struct packet{
	int size;
	double ts;
	int length;
	int ID;
	int TTL;
	int protocol;

	char ip_src[MAX_STR_LEN];
	char ip_dest[MAX_STR_LEN];
	int port_src;
	int port_dest;

	uint8_t tcp_flags;


	struct packet* nextpacket;
};

// CONNECTION STRUCT / PACKET LIST HEAD
struct connection{
	struct packet* nextpacket;
  char ip_src[MAX_STR_LEN]; /*source ip*/
  char ip_dest[MAX_STR_LEN]; /*destination ip*/
  int port_src; /*source port number*/
  int port_dest; /*destination port number*/

  int syn_count; /*flag count*/
  int fin_count;
  int rst_count;
  struct timeval starting_time;
  struct timeval ending_time;
  double duration;

  int num_packet_src; /*number of packets sent out by source*/
  int num_packet_dst; /*number of packets sent out by destination*/
  int num_total_packets;

  int cur_data_len_src; /*num data bytes*/
  int cur_data_len_dst; /*num data bytes*/
  int cur_total_data_len;

  uint16_t max_win_size; /*max window size*/
  uint16_t min_win_size; /*min window size*/
  double sum_win_size;

  // struct round_trip rtt_ary_src[MAX_NUM_CONNECTION/4]; /*assume 1000*/
  int rtt_ary_src_len; /*the size of the rtt_ary_src array*/
  // struct round_trip rtt_ary_dst[MAX_NUM_CONNECTION/4]; /*assume 1000*/
  int rtt_ary_dst_len; /*the size of the rtt_ary_dst array*/
  int is_set;
};
