/* Assignment 2
 * Jakob Roberts
 * CSC 361
 */
//===================================================================
#include "p2.h"
//===================================================================
//===================================================================
//===================================================================
// Process a received packet and enter into a packet struct
struct packet* process_packet(const unsigned char *pack,struct timeval ts, unsigned int caplen){
	// Initialize new packet
	struct packet *outpack = malloc(sizeof(struct packet));
	if(outpack == NULL){
		printf("MALLOC FAILED\n");
		return NULL;
	}
	outpack->nextpacket = NULL;
	// printf("caplen: %d\t",caplen);

	// Get timestamp for packet
	outpack->ts = (ts.tv_sec * 1000000.0 + ts.tv_usec)/1000000;

	// Setup header vars
	struct iphdr* iphead;
	unsigned int IP_header_length;

	// Bypass Ethernet Header
	// return null if not a full header
	if (caplen < sizeof(struct ether_header)){
		return NULL;
	}else{
		pack += sizeof(struct ether_header);
		caplen -= sizeof(struct ether_header);
	}

	// Gather IP Header info
	// return null if not a full header
	if (caplen < sizeof(struct ip)){
		return NULL;
	}else{
		// Get IP header information
		iphead = (struct iphdr*) pack;
		outpack->size     = (int)caplen;
		outpack->length   = (int)ntohs(iphead->tot_len);
		outpack->ID       = (int)ntohs(iphead->id);
		outpack->TTL      = (int)iphead->ttl;
		outpack->protocol = (int)iphead->protocol;
		inet_ntop(AF_INET, &(iphead->saddr), outpack->ip_src , INET_ADDRSTRLEN);
		inet_ntop(AF_INET, &(iphead->daddr), outpack->ip_dest, INET_ADDRSTRLEN);
	}
	struct ip *ip;
	ip = (struct ip*) pack;
	IP_header_length = ip->ip_hl * 4;	/* ip_hl is in 4-byte words */
	// printf("%d   ",IP_header_length);
	pack += IP_header_length;
	// printf("%d\n",pack);
	struct TCP_hdr* tcp;
	tcp = (struct TCP_hdr*) pack;

	// printf("%d %d %d %d %d %" PRIu8" %d %d\n",
	// // timestamp_string(ts),
	// ntohs(tcp->src_port),
	// ntohs(tcp->dst_port),
	// ntohs(tcp->sent_seq),
	// ntohs(tcp->recv_ack),
	// ntohs(tcp->data_off),
	// ntohs(tcp->tcp_flags),
	// ntohs(tcp->rx_win),
	// ntohs(tcp->cksum),
	// ntohs(tcp->tcp_urp)
	// );

	outpack->port_src  = ntohs(tcp->src_port);
	outpack->port_dest = ntohs(tcp->dst_port);
	outpack->tcp_flags = tcp->tcp_flags;


	return outpack;
}
//===================================================================
int main(int argc,char **argv){
	int i;
	//number of connections
	int numconns = 0;

	// Check arg input
	if (argc < 2) {
    fprintf(stderr, "Usage: %s <pcap>\n", argv[0]);
    exit(1);
  }

  // Open PCAP File
  pcap_t *capfile;
	char errbuf[PCAP_ERRBUF_SIZE];
	capfile = pcap_open_offline(argv[1], errbuf);
	if (capfile == NULL) {
		fprintf(stderr,"Couldn't open pcap file %s: %s\n", argv[1], errbuf);
		return(2);
	}

	// Initialize connecion array
	struct connection conns[MAX_NUM_CONNECTION];
	for(i=0;i<MAX_NUM_CONNECTION-1;i++){
		conns[i].is_set=0;
		conns[i].nextpacket=NULL;
		conns[i].num_packet_src=0;
		conns[i].num_packet_dst=0;
		conns[i].cur_data_len_src=0;
		conns[i].cur_data_len_dst=0;
	}

	//packet initialization
	const unsigned char *pack;
	struct pcap_pkthdr header;
	struct TCP_hdr tcp;

	//go through packets
	while ((pack = pcap_next(capfile,&header))){
		struct packet* data;
		// if(data == NULL){
		// 	printf("MALLOC FAILED\n");
		// }
		if(pack != NULL){
			data = process_packet(pack,header.ts,header.len);
		}

		if (data != NULL){
			for(i=0;i<MAX_NUM_CONNECTION-1;i++){

				if(conns[i].is_set == 1){
					int go = 0;
					if((strcmp(data->ip_src,conns[i].ip_src) && strcmp(data->ip_dest,conns[i].ip_dest) ) ){
						if((conns[i].port_dest == data->port_src) && (conns[i].port_src == data->port_dest)){
							go++;
							conns[i].num_packet_src++;
							conns[i].cur_data_len_src+=header.len;
						}
					}else if(((strcmp(data->ip_src,conns[i].ip_dest) && strcmp(data->ip_dest,conns[i].ip_src)) )){
						if(!(conns[i].port_src - data->port_src) && !(conns[i].port_dest - data->port_dest)){
							go++;
							conns[i].num_packet_dst++;
							conns[i].cur_data_len_dst+=header.len;
						}
					}
					if (go){
						struct packet * current = conns[i].nextpacket;
						while(current->nextpacket!=NULL){
							current = current->nextpacket;
						}
						current->nextpacket = data;
						break;
					}
				}else if(conns[i].is_set == 0){
					numconns++;
					conns[i].is_set=1;
					strncpy(conns[i].ip_src, data->ip_src,strlen(data->ip_src));
					strncpy(conns[i].ip_dest, data->ip_dest,strlen(data->ip_dest));
					conns[i].port_src = data->port_src;
					conns[i].port_dest = data->port_dest;

					conns[i].nextpacket = data;
					// printf("made it here %d\n",conns[i].nextpacket->ID);
					conns[i].num_packet_src++;
					break;
				}else{
					printf("Failed conns array init!\n");
				}
			}
		}else{
			printf("\nPACKET NOT COMPATIBLE\n\n");
		}
	}

	//PART A
	printf("A) Total number of connections: %d\n-------------------------------------------------------- \nB) Connections' details: \n",numconns);

	//PART B
	//Go through connections and get + print required data
	int firstpack=0;
	double basetime;
	for(i=0;i<numconns;i++){
		double tmin = 0;
		double tmax = 0;
		double duration;
		struct packet* current = conns[i].nextpacket;


		if(!firstpack){
			basetime = current->ts;
			firstpack = 1;
		}

		tmin = current->ts;
		while(current->nextpacket!=NULL){
			//get max time
			if(current->ts > tmax){
				tmax = current->ts;
			}
			if((current->tcp_flags & 0x01)>0){
  			conns[i].fin_count++;
			}
			if((current->tcp_flags & 0x02)>0){
  			conns[i].syn_count++;
			}
			if((current->tcp_flags & 0x04)>0){
  			conns[i].rst_count++;
			}







			current = current->nextpacket;
		}
		if(current->ts > tmax){
			tmax = current->ts;
		}
		if((current->tcp_flags & 0x01)>0){
  			conns[i].fin_count++;
		}
		if((current->tcp_flags & 0x02)>0){
			conns[i].syn_count++;
		}
		if((current->tcp_flags & 0x04)>0){
			conns[i].rst_count++;
		}

		tmin -= basetime;
		tmax -= basetime;
		duration = tmax - tmin;


		printf("Connection %d:\n",i+1);
		printf("Source Address: %s\n",conns[i].ip_src);
		printf("Destination address: %s\n",conns[i].ip_dest);
		printf("Source Port: %d\n",conns[i].port_src);
		printf("Destination Port: %d\n",conns[i].port_dest);
		printf("Status: S%dF%d\n",conns[i].syn_count,conns[i].fin_count);

		if(conns[i].fin_count >0 && conns[i].syn_count>0){
			printf("Start time: %f\n",tmin);
			printf("End Time: %f\n",tmax);
			printf("Duration: %f\n",duration);
			printf("Number of packets sent from Source to Destination: %d\n",conns[i].num_packet_src);
			printf("Number of packets sent from Destination to Source: %d\n",conns[i].num_packet_dst);
			printf("Total number of packets: %d\n",conns[i].num_packet_src+conns[i].num_packet_dst);
			printf("Number of data bytes sent from Source to Destination: %d\n",conns[i].cur_data_len_src);
			printf("Number of data bytes sent from Destination to Source: %d\n",conns[i].cur_data_len_dst);
			printf("Total number of data bytes: %d\n",conns[i].cur_data_len_src+conns[i].cur_data_len_dst);
		}

		printf("END\n+++++++++++++++++++++++++++++++++\n");
	}

	// PART C
	printf("\nC) General :\n");
	int comp = 0;
	int res  = 0;
	int open = 0;
	for(i=0;i<numconns;i++){
		if(conns[i].fin_count >0 && conns[i].syn_count>0){
			comp++;
		}
		if(conns[i].rst_count>0){
			res++;
		}
		if(conns[i].fin_count == 0 && conns[i].syn_count>=0){
			open++;
		}
	}
	printf("Total number of complete TCP connections: %d\n",comp);
	printf("Number of reset TCP connections: %d\n",res);
	printf("Number of TCP connections that were still open when the trace capture ended: %d\n",open);


	printf("\n");
	// Clean up
	pcap_close(capfile);
}


